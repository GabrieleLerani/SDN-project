import pox.openflow.libopenflow_01 as of
from pox.core import core
from pox.lib.addresses import EthAddr
from pox.lib.addresses import IPAddr
from pox.lib.packet.ethernet import ethernet
from pox.lib.packet.arp import arp
from util import check_same_network
from datetime import datetime

log = core.getLogger()

class ARPComponent:
    def __init__(self) -> None:
        core.openflow.addListeners(self)
        self.gw_ip = IPAddr("10.0.0.1")
        #self.gw_mac = EthAddr("00:00:01:01:01:01") # For kathara execution
        self.gw_mac = EthAddr("00:00:00:12:34:56") # For mininet execution 
        self.net_mask = "255.255.255.0"

    def _handle_PacketIn(self, event):
        packet = event.parsed
        if packet.type == packet.ARP_TYPE and packet.payload.opcode == arp.REQUEST:
            
            arp_packet = packet.payload
            
            # arp request for the gw
            if ((not check_same_network(packet.payload.protodst, self.gw_ip, self.net_mask)) or packet.payload.protodst == self.gw_ip):
                
                #self.pretty_request_print(arp_packet)                
                self.install_ARP_rule(event, arp_packet, gw_rule=True)
                self._handle_ARP_Request(event, arp_packet, gw_rule=True)

            # arp request for hosts
            elif (packet.payload.protodst in core.hostDiscovery.hosts.keys()):
                
                #self.pretty_request_print(arp_packet)                
                self.install_ARP_rule(event,arp_packet)
                self._handle_ARP_Request(event,arp_packet)


    def install_ARP_rule(self, event, arp_packet, gw_rule = False):
        """
        Send the rule to handle ARP REPLY message 
        """

        msg = of.ofp_flow_mod()
        
        dl_src = self.gw_mac if gw_rule else core.hostDiscovery.hosts[arp_packet.protodst]["mac"]
        dl_dst = arp_packet.hwsrc

        msg.match = of.ofp_match(
            dl_type=ethernet.ARP_TYPE, dl_src=dl_src, dl_dst=dl_dst
        )
        msg.hard_timeout = 5

        msg.actions.append(of.ofp_action_output(port=event.ofp.in_port))
        event.connection.send(msg)


    def _handle_ARP_Request(self, event, arp_packet, gw_rule = False):
        """
        Create an ARP reply message and sand back to the input port
        """

        # Create ARP reply message
        arp_reply = arp()
        arp_reply.opcode = arp.REPLY

        # insert the mac address of the requested host
        arp_reply.hwsrc = self.gw_mac if gw_rule else core.hostDiscovery.hosts[arp_packet.protodst]["mac"]
        arp_reply.hwdst = arp_packet.hwsrc
        arp_reply.protosrc = arp_packet.protodst
        arp_reply.protodst = arp_packet.protosrc

        # Create ethernet frame
        ether = ethernet()
        ether.type = ethernet.ARP_TYPE
        ether.dst = arp_packet.hwsrc
        ether.src = self.gw_mac if gw_rule else core.hostDiscovery.hosts[arp_packet.protodst]["mac"]
        ether.payload = arp_reply
        
        # Create openflow msg and send with a packet out
        msg = of.ofp_packet_out()
        msg.data = ether.pack()
        msg.actions.append(of.ofp_action_output(port=event.port))
        event.connection.send(msg)
        #self.pretty_reply_print(arp_packet.protodst,arp_reply.hwsrc)
    
    @staticmethod
    def pretty_request_print(arp_packet):
        timestamp = datetime.now().strftime("%H:%M:%S,%f")[:-3]
        log.info(f"{timestamp} ARP, Request who-has {arp_packet.protodst} tell {arp_packet.protosrc}")    
        

    @staticmethod
    def pretty_reply_print(ip,mac):
        timestamp = datetime.now().strftime("%H:%M:%S,%f")[:-3]
        log.info(f"{timestamp} ARP, Reply {ip} is-at {mac}")    

def launch():
    core.registerNew(ARPComponent)
