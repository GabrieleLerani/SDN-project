import networkx as nx
from pox.core import core
from datetime import datetime

log = core.getLogger()

class Graph:
    
    def __init__(self,componentLinkDiscovery):
        componentLinkDiscovery.addListeners(self)
        core.openflow.addListeners(self)
        self.graph = None
    

    def _handle_linkDiscovered(self,event):
        timestamp = datetime.now().strftime("%H:%M:%S,%f")[:-3]
        log.info(f"{timestamp} building network graph")
        self.graph = self.get_graph()

    def get_graph(self):
        
        G = nx.Graph()
        nodes = list(core.linkDiscovery.switch_id.keys())
        G.add_nodes_from(nodes)
        for link in core.linkDiscovery.links:
            sid1 = core.linkDiscovery.links[link].sid1 
            sid2 = core.linkDiscovery.links[link].sid2
            weight = core.linkDiscovery.links[link].flow  # Get flows of the link
            G.add_edge(sid1,sid2,weight=weight)
        
        timestamp = datetime.now().strftime("%H:%M:%S,%f")[:-3]
        log.info(f"{timestamp} {G}")
        log.debug(f"{timestamp} {G.edges.data()}")
        return G
    

    def update_weight(self, G, u, v, new_weight, decrement = False):
        if G.has_edge(u,v):
            G[u][v]["weight"] += new_weight if not decrement else -1 * new_weight
        else:
            log.error(f"({u},{v}) not in graph")



def launch():
    core.register(Graph(core.linkDiscovery))