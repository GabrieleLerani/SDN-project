import networkx as nx
from pox.core import core
from datetime import datetime

log = core.getLogger()

class Graph:
    
    def __init__(self,componentLinkDiscovery):
        componentLinkDiscovery.addListeners(self)
        core.openflow.addListeners(self)
        self.graph = nx.Graph()
    

    def _handle_linkDiscovered(self,event):
        self.update_graph(event)

    def update_graph(self,event):
        
        sid1 = core.linkDiscovery.links[event.link.name].sid1 
        sid2 = core.linkDiscovery.links[event.link.name].sid2
        weight = core.linkDiscovery.links[event.link.name].flow
        if not self.graph.has_node(sid1):
            self.graph.add_node(sid1)
        if not self.graph.has_node(sid2):
            self.graph.add_node(sid2)
        if not self.graph.has_edge(sid1,sid2):
            self.graph.add_edge(sid1,sid2,weight=weight)
        
        timestamp = datetime.now().strftime("%H:%M:%S,%f")[:-3]
        log.info(f"{timestamp} {self.graph}")
        log.debug(f"{timestamp} {self.graph.edges.data()}")
        

    def update_weight(self, G, u, v, new_weight, decrement = False):
        if G.has_edge(u,v):
            G[u][v]["weight"] += new_weight if not decrement else -1 * new_weight
        else:
            log.error(f"({u},{v}) not in graph")



def launch():
    core.register(Graph(core.linkDiscovery))
