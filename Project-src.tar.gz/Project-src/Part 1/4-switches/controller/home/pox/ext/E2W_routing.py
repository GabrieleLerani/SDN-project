import pox.openflow.libopenflow_01 as of
from pox.core import core
from pox.lib.packet.ethernet import ethernet
from pox.lib.util import dpidToStr
from util import get_links_pair
from util import get_key_from_value
from datetime import datetime
from pox.lib.recoco import Timer
import networkx as nx

log = core.getLogger()

E2W_IDLE_TIMEOUT = 20

class E2WRouting:
    def __init__(self):
        core.openflow.addListeners(self)
        self.flows = {}
        Timer(15, self.request_statistics, recurring=True)

    def _handle_PacketIn(self, event):
        packet = event.parsed
        
        # discard all icmp replay from the gateway, consider only internal traffic
        if (packet.find('ipv4') and
            packet.src != core.ARPComponent.gw_mac and
            packet.dst != core.ARPComponent.gw_mac):
                
            ip_packet = packet.payload
            src_ip = ip_packet.srcip
            dst_ip = ip_packet.dstip
            self.route_traffic_flows(src_ip,dst_ip)
    
        
    def _handle_FlowStatsReceived (self, event):
        IP_bytes = 0
        IP_flows = 0
        for f in event.stats:
            if f.match.dl_type == ethernet.IP_TYPE:
                IP_bytes += f.byte_count
                IP_flows += 1
        sw_id = get_key_from_value(core.linkDiscovery.switch_id, event.dpid)
        log.info(f"switch {sw_id} IP traffic: {IP_bytes} bytes over {IP_flows} flows")
            

    def request_statistics(self):
        # Now actually request flow stats from all switches
        for con in core.openflow.connections: 
            con.send(of.ofp_stats_request(body=of.ofp_flow_stats_request()))

    def _handle_FlowRemoved(self, event):
        if event.idleTimeout:
            flow_match = event.ofp.match
            
            sw_id = get_key_from_value(core.linkDiscovery.switch_id, event.dpid)
            timestamp = datetime.now().strftime("%H:%M:%S,%f")[:-3]
            log.info(f"{timestamp} switch {sw_id,dpidToStr(event.dpid)} has removed flow for E2W traffic between {flow_match.nw_src} and {flow_match.nw_dst}")
    

            flow_id = (
                    flow_match.nw_src,
                    flow_match.nw_dst,
                    flow_match.dl_type
            )

            if flow_id in self.flows.keys():

                graph = core.Graph.graph

                # decrease flow counter for every link used by the flow
                for link in self.flows[flow_id]:    
                    core.Graph.update_weight(graph,link[0],link[1],1,decrement=True)

                # remove flow 
                del self.flows[flow_id]

                
     
    def route_traffic_flows(self,src_host_ip,dst_host_ip):
            
        # get the switch dpid of the src
        sw_src = core.hostDiscovery.hosts[src_host_ip]["switch"]

        # get the switch dpid of the dst
        sw_dst = core.hostDiscovery.hosts[dst_host_ip]["switch"]

        # get the port of the switch where the host is connected with
        sw_to_host_port = core.hostDiscovery.hosts[dst_host_ip]["port"] 
 
        # get the id of the source switch
        S = get_key_from_value(core.linkDiscovery.switch_id, sw_src)

        # get the id of the destination switch
        D = get_key_from_value(core.linkDiscovery.switch_id, sw_dst)     

        # get network graph
        graph = core.Graph.graph

        # compute the shortest path between S and D according to the path weight
        path = list(nx.shortest_path(graph, S, D, weight="weight"))

        # get path links as a list of tuple: [(1,2),(2,3)...]
        path_links = get_links_pair(path)
        
        timestamp = datetime.now().strftime("%H:%M:%S,%f")[:-3]
        log.info(f"{timestamp} found path for traffics between {src_host_ip} and {dst_host_ip}: {path}")

        # a flow is identified by src ip and dst ip, it should be changed to consider 
        # different flows from the same host to the same machine
        flow_id = (src_host_ip, dst_host_ip, ethernet.IP_TYPE)
        
        # store the path associated to a flow
        self.flows[flow_id] = path_links

        # define the flow rule
        msg = of.ofp_flow_mod()
        msg.idle_timeout = E2W_IDLE_TIMEOUT            
        
        # Send flow removed message when rule expire
        msg.flags = of.OFPFF_SEND_FLOW_REM
        msg.match = of.ofp_match(
            dl_type=ethernet.IP_TYPE, 
            nw_src = src_host_ip,
            nw_dst = dst_host_ip,
        )

        if len(path) == 1:
            msg.actions = [of.ofp_action_output(port=sw_to_host_port)]  
            core.openflow.sendToDPID(sw_dst, msg)
                
        else:

            for sw in path_links:
                
                src_dpid = core.linkDiscovery.switch_id[sw[0]]
                link_name = f"{sw[0]}_{sw[1]}"
                out_port = core.linkDiscovery.links[link_name].port1

                # increment flow on that edge
                core.Graph.update_weight(graph,sw[0],sw[1],1)

                flow = graph[sw[0]][sw[1]]["weight"]

                timestamp = datetime.now().strftime("%H:%M:%S,%f")[:-3]
                log.info(f"{timestamp} now link {link_name} has {flow} flow")

                msg.actions = [of.ofp_action_output(port=out_port)]  
                core.openflow.sendToDPID(src_dpid, msg)
                log.debug(f"{timestamp} E2W flow rule sent to {dpidToStr(src_dpid)}")
                if sw[1] == D:
                    msg.actions = [of.ofp_action_output(port=sw_to_host_port)]  
                    core.openflow.sendToDPID(sw_dst, msg)
                    log.debug(f"{timestamp} E2W flow rule sent to {dpidToStr(sw_dst)}")
        
        

def launch():
    core.registerNew(E2WRouting)